# Fused output follow-up after #56935

Inspected #56935 head 7cbfd2049489025046919a8d472584972d3eecc2,
parent e6eb0d120c480aa5116aafc2d39f19c8ebcf3181. Native wheel matches
parent; csrc and selected dependency files are unchanged by the PR.

- #56344 is closed after its base branch was deleted.
- #56544 remains an open draft targeting vllm-project/vllm:v41-megakernel.
- #56935 replaces #56344 and targets main from zyongye/vllm:v41-megakernel.
  These identically named head branches belong to different repositories.
- FlashMLA #23 delivered caller-owned outputs. #56935's parent already pins
  the later 0eee43b native revision exposing that ABI.
- #56935 already allocates QuantizedActivation before the eager region, fills
  disjoint prefill/decode token slices, and calls wo_a/wo_b after the region.
  Porting #56544 verbatim would duplicate its core behavior.
- #56935 has no split-KV fallback threshold. Test its unfused backend control;
  do not restore the retired threshold just to reproduce an old harness.

## Approved work adapted to the actual remaining gap

1. Confirm source/native compatibility and compare the implementations.
2. Run MRV2 real-model startup, arithmetic, mixed requests and a GSM8K32 canary.
3. Only after correctness passes, compare mega versus split-KV on the SAME
   branch/native build and explicit fp8_ds_mla format, matched prompt lengths,
   generated-token counts and scheduler steps. This comparison measures backend
   selection, not an isolated #56544 contribution. NVFP4 accuracy is a separate
   canary if the path works.
4. If a concrete bug appears, isolate it, add a regression test, and prepare a
   focused follow-up against #56935's branch. Keep new fixes private pending
   human line review/test rerun before upstream submission.
5. If no distinct change remains, retain historical #56544 evidence and mark
   its current relationship accurately instead of manufacturing a duplicate PR.

Bound: TP4 GB200, MRV2 graphs, 17/8192 input tokens, B1, 64 generated tokens,
2 warmups plus 3 repeats per engine. Mixed 17/16384 requests generate 32 tokens.
At most a matched A/B/B/A after the first correctness gate; no broad sweep.
Stop timing on incorrect model output, failed route checks, scheduler mismatch,
preemption, or foreign GPU occupancy. Record failures as failures, not speedups.

## Distinct bounded follow-up

Source inspection found `pad_fused_q_heads` allocating and launching inside
`forward_mqa`, which is in the eager region. The existing
`_prepare_q_and_insert_kv` hook runs before that region on MRV2 and can publish
already-padded Q. This does not duplicate #56544's output-side work.

Candidate worktree: vllm-mega-qpad, branch perf/dsv41-mega-captured-qpad.
Move only Q padding into that hook; keep the native kernel, FP8 record and
output projection unchanged. Unit regression checks use changing Q across
capture/replay, preserve every live fused-layout chunk, and zero padded heads.
The two 16-head regression cases fail on the original PR head; candidate's
nine layout tests and 31 merged-native output-buffer tests pass.

Adoption gate: same-branch mega control vs captured-padding candidate, >=5%
short-prefill TTFT improvement in both order comparisons, no >2% TPOT
regression, matching scheduler steps and no changed accuracy outcomes on the
small canary. Decode speed is not the motivation. A split-KV comparison is
reported separately; early TP4 control is faster than mega by about 10% TPOT.
Stop if no repeatable short-prefill gain or correctness/regression gate fails.
