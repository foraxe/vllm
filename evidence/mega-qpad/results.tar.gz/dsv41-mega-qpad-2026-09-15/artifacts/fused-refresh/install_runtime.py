import hashlib,json,subprocess,urllib.request,zipfile
from pathlib import Path
root=Path('/workspace/vllm_dsv41'); work=root/'vllm-mega-56935'
sha=subprocess.check_output(['git','rev-parse','HEAD^'],cwd=work,text=True).strip()
metadata=json.loads((root/'artifacts/fused-refresh/wheel-metadata.json').read_text())
entry=next(x for x in metadata if 'aarch64' in x['platform_tag'])
url=f'https://wheels.vllm.ai/{sha}/'+entry['filename'].replace('+','%2B')
wheel=root/'artifacts/fused-refresh/current-native.whl';dest=root/'native-mega-e6eb0d1'
if not wheel.exists():urllib.request.urlretrieve(url,wheel)
with zipfile.ZipFile(wheel) as z:
 for name in z.namelist():
  if name.startswith('vllm/') and (name.endswith('.so') or name.endswith('/_version.py') or name.startswith('vllm/third_party/flashmla/') or name.startswith('vllm/vllm_flash_attn/cute/')):
   if name.endswith('/'):continue
   z.extract(name,dest)
   target=work/name;target.parent.mkdir(parents=True,exist_ok=True)
   if target.is_symlink():target.unlink()
   elif target.exists():continue
   target.symlink_to(dest/name)
venv=work/'.venv'
if not venv.exists():venv.symlink_to(root/'vllm-engram-vmm/.venv',target_is_directory=True)
changed=subprocess.check_output(['git','diff','HEAD^','HEAD','--name-only','--','csrc','cmake/external_projects'],cwd=work,text=True)
assert not changed,changed
(root/'artifacts/fused-refresh/native-provenance.json').write_text(json.dumps({'wheel_commit':sha,'wheel_url':url,'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'pr_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),'native_source_diff':changed},indent=2)+'\n')
print('Native runtime installed',sha,flush=True)
