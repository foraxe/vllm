## Summary

On MRV2 piecewise prefill, the mega-attention backend currently allocates and
pads Q inside the eager attention region on each layer. Prepare the padded Q
through `_prepare_q_and_insert_kv` so the allocation and padding launch are
captured before the sparse indexer/attention break. `forward_mqa` consumes the
prepared buffer. The native kernel and its FP8 output handoff are unchanged.

```text
ASIS
graph [Q projection, KV insert] -> eager [Q padding, indexer, mega attention]
```

```text
PR
graph [Q projection, KV insert, Q padding] -> eager [indexer, mega attention]
```

This is a focused follow-up to vllm-project/vllm#56935. That replacement already
contains the shared FP8 output/projection design from the direction explored in
#56544; this patch addresses the remaining input padding inside the eager break.
No split-KV fallback is added. FULL decode already captures padding, so the
motivation is short-prefill dispatch overhead.

## Validation

- Nine layout tests pass, including changing-input padding through CUDA graph
  replay and a no-padding head count. Both new 16-head regression cases fail on
  the parent branch and pass with the change.
- The pinned FlashMLA caller-output suite passes all 31 cases.
- Applicable pre-commit hooks and Python 3.12 mypy pass.
- TP4 GB200, official DeepSeek-V4.1-Flash, MRV2 FULL_AND_PIECEWISE, explicit
  fp8_ds_mla, fixed 4 GiB KV/rank, APC off. Two model loads per arm in
  control/candidate/candidate/control order, two warmups plus three measured
  requests per context/load, 64 output tokens. A separate split-KV control ran
  between the first two loads. Prompt hashes and scheduler steps match.
- Short-prefill (17 tokens) TTFT: 24.915 -> 22.743 ms (-8.72%). Both order
  comparisons favor the change: 25.007/22.600 and 24.823/22.963 ms.
  Eager padding calls fall from 40 to zero per worker; the diagnostic uses one
  piecewise and two full-graph replays. Diagnostic hooks are removed for timing.
  All 20 short-context completions including warmups match token-for-token.
- TPOT changes stay within 0.51%; no decode speedup claimed. The 8K TTFT result
  is order-sensitive; no long-context speedup claimed. These are bounded offline
  engine measurements, not HTTP serving results.
- Mixed 17/16384-token requests complete with matching scheduler traces and
  32 output tokens each. Full token equality is not claimed for mixed/long
  outputs: control 8K generations also vary between identical requests.
- GSM8K32 five-shot: control 31/32 and 32/32; candidate 32/32 on both loads.
  A separate NVFP4-default candidate canary passes arithmetic/mixed execution
  and scores 31/32. No output caps reached. This is a small accuracy canary,
  not broad accuracy or model-level bitwise qualification.
- Retained PyTorch allocation after mixed/8K prefill is unchanged at about
  83.1103 GiB/rank. Reserved memory rises by 2 MiB/rank. The first mixed run's
  transient peak rises by 0.312 GiB/rank; automatic KV sizing is not qualified.
- MRV1, DBO, speculative decoding, other TP sizes and other devices are untested.

Commands (with the report's source/native/runtime overlay and GPU lease):

```bash
.venv/bin/python -m pytest -q tests/kernels/test_dsv41_mega_attn_layouts.py
.venv/bin/python -m pytest -q tests/test_fused_optional_out.py  # pinned FlashMLA checkout
.venv/bin/python mega_bench.py --backend mega --gsm --output run.json
pre-commit run --files vllm/models/deepseek_v41/nvidia/flash_mla_mega_attn.py tests/kernels/test_dsv41_mega_attn_layouts.py
```

AI assistance was used for implementation, validation and investigation.
