import hashlib,json,statistics
from pathlib import Path
root=Path(__file__).resolve().parent
names=['mega-fp8-first','qpad-fp8-c1','qpad-fp8-c2','mega-fp8-b2']
data={name:json.loads((root/(name+'.json')).read_text()) for name in names}
summary={'order':names,'note':'A separate split-KV control ran between the first mega control and first candidate. Timed projections/padding/graph diagnostics were removed before warmups.','cases':{},'gsm8k':{},'diagnostics':{}}
for length in [17,8192]:
 groups={}
 for arm,select in [('control',[names[0],names[3]]),('candidate',[names[1],names[2]])]:
  cases=[next(c for c in data[n]['cases'] if c['length']==length) for n in select]
  runs=[r for c in cases for r in c['runs']]
  groups[arm]={'medians':{k:statistics.median(r[k] for r in runs) for k in ['mean_ttft_ms','mean_tpot_ms','output_tokens_per_s']},'ttft_runs':[statistics.median(r['mean_ttft_ms'] for r in c['runs']) for c in cases], 'all_outputs': [tuple(r['outputs'][0]['tokens']) for c in cases for r in c['warmups']+c['runs']], 'scheduler_signatures':sorted({r['scheduler_signature'] for r in runs}), 'prompt_hashes':sorted({c['prompt_sha256'] for c in cases})}
 assert groups['control']['scheduler_signatures']==groups['candidate']['scheduler_signatures']
 assert len(groups['control']['scheduler_signatures'])==1
 assert groups['control']['prompt_hashes']==groups['candidate']['prompt_hashes']
 groups['ttft_change_percent']=100*(groups['candidate']['medians']['mean_ttft_ms']/groups['control']['medians']['mean_ttft_ms']-1)
 groups['tpot_change_percent']=100*(groups['candidate']['medians']['mean_tpot_ms']/groups['control']['medians']['mean_tpot_ms']-1)
 groups['paired_exact_output_count']=sum(a==b for a,b in zip(groups['control']['all_outputs'],groups['candidate']['all_outputs']))
 groups['paired_output_count']=len(groups['control']['all_outputs'])
 for arm in ['control','candidate']:
  groups[arm]['unique_token_sequences']=len(set(groups[arm].pop('all_outputs')))
 summary['cases'][length]=groups
for name,d in data.items():
 summary['gsm8k'][name]={'correct':d['gsm8k_correct'],'wrong_ids':[x['id'] for x in d['gsm8k'] if not x['correct']]}
 summary['diagnostics'][name]=d['diagnostic']
summary['gsm8k']['exact_control_repeats']=sum(a['tokens']==b['tokens'] for a,b in zip(data[names[0]]['gsm8k'],data[names[3]]['gsm8k']))
summary['gsm8k']['exact_candidate_repeats']=sum(a['tokens']==b['tokens'] for a,b in zip(data[names[1]]['gsm8k'],data[names[2]]['gsm8k']))
summary['mixed']={'scheduler_signatures':sorted({d['mixed']['scheduler_signature'] for d in data.values()}),'unique_output_pairs':len({tuple(tuple(o['tokens']) for o in d['mixed']['outputs']) for d in data.values()})}
assert len(summary['mixed']['scheduler_signatures'])==1
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for length,case in summary['cases'].items():print(length,{k:v for k,v in case.items() if k not in ['control','candidate']}, 'control',case['control']['medians'],'candidate',case['candidate']['medians'])
print('gsm8k',summary['gsm8k']);print('mixed',summary['mixed'])
