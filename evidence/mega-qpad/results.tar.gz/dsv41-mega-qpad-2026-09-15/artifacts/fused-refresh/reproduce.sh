#!/usr/bin/env bash
set -euo pipefail
cd /workspace/vllm_dsv41
mode=${1:-tests}
out=${2:-/tmp/dsv41-mega-qpad}
mkdir -p "$out"
MEGA_RUNTIME_PATH=$PWD/artifacts/fused-refresh:$PWD/engram-runtime-deps:$PWD/dcp-runtime-deps/nvidia_cutlass_dsl/dsl_packages:$PWD/dcp-runtime-deps:$PWD/runtime-deps
export PYTHONPATH=$MEGA_RUNTIME_PATH:$PWD/vllm-mega-qpad
export VLLM_USE_V2_MODEL_RUNNER=1 VLLM_DEEP_GEMM_WARMUP=skip
# Acquire a shared GPU lease and check occupancy before GPU modes.
case "$mode" in
  tests)
    export CUDA_VISIBLE_DEVICES=0
    vllm-mega-qpad/.venv/bin/python -m pytest -q vllm-mega-qpad/tests/kernels/test_dsv41_mega_attn_layouts.py
    ;;
  native)
    export CUDA_VISIBLE_DEVICES=0
    export PYTHONPATH=$PWD/flashmla-mega-native:$PYTHONPATH
    vllm-mega-qpad/.venv/bin/python -m pytest -q flashmla-mega-native/tests/test_fused_optional_out.py
    ;;
  candidate|control)
    export CUDA_VISIBLE_DEVICES=0,1,2,3
    if [[ "$mode" == control ]]; then export PYTHONPATH=$MEGA_RUNTIME_PATH:$PWD/vllm-mega-56935; fi
    vllm-mega-qpad/.venv/bin/python artifacts/fused-refresh/mega_bench.py --backend mega --gsm --output "$out/$mode.json"
    ;;
  nvfp4)
    export CUDA_VISIBLE_DEVICES=0,1,2,3
    vllm-mega-qpad/.venv/bin/python artifacts/fused-refresh/mega_bench.py --backend mega --kv-dtype nvfp4_ds_mla --contexts 17 --repeats 1 --gsm --output "$out/nvfp4.json"
    ;;
  lint)
    cd vllm-mega-qpad
    .venv/bin/pre-commit run --files vllm/models/deepseek_v41/nvidia/flash_mla_mega_attn.py tests/kernels/test_dsv41_mega_attn_layouts.py
    .venv/bin/pre-commit run mypy-3.12 --hook-stage manual --files vllm/models/deepseek_v41/nvidia/flash_mla_mega_attn.py tests/kernels/test_dsv41_mega_attn_layouts.py
    ;;
  *) echo 'usage: reproduce.sh {tests|native|candidate|control|nvfp4|lint} [output-dir]' >&2; exit 2 ;;
esac
