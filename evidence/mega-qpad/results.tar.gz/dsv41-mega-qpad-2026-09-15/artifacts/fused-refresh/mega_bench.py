"""Pinned #56935 MRV2 engine checks with matched workload accounting."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT=Path('/workspace/vllm_dsv41')
sys.path.insert(0,str(ROOT/'artifacts/dcp/performance'))
import benchmark as perf
from vllm import LLM,SamplingParams

class MegaWorker(perf.PerfWorker):
    def load_model(self,**kwargs):
        import torch
        from vllm.models.deepseek_v41.nvidia.flash_mla_mega_attn import DeepseekV4MegaAttnAttention as Mega
        self.projections={'capture':0,'eager':0}
        self.padding={'capture':0,'eager':0}
        import vllm.models.deepseek_v41.nvidia.flash_mla_mega_attn as mega_module
        self.original_padding=mega_module.pad_fused_q_heads
        original_padding=self.original_padding
        def count_padding(*args,**kwargs):
            self.padding['capture' if torch.cuda.is_current_stream_capturing() else 'eager']+=1
            return original_padding(*args,**kwargs)
        mega_module.pad_fused_q_heads=count_padding
        self.original_projection=Mega._wo_a_einsum
        original=self.original_projection
        def count(layer,*args,**kw):
            self.projections['capture' if torch.cuda.is_current_stream_capturing() else 'eager']+=1
            return original(layer,*args,**kw)
        Mega._wo_a_einsum=count
        super().load_model(**kwargs)
        assert self.vllm_config.use_v2_model_runner
        from vllm.v1.worker.gpu.cudagraph_utils import CudaGraphManager
        self.replays={}
        self.graph_originals={}
        for name in ('run_fullgraph','run_pw_graph'):
            original_graph=getattr(CudaGraphManager,name)
            self.graph_originals[name]=original_graph
            def count_graph(manager,*args,_name=name,_original=original_graph,**kw):
                self.replays[_name]=self.replays.get(_name,0)+1
                return _original(manager,*args,**kw)
            setattr(CudaGraphManager,name,count_graph)
    def begin_run(self):
        import torch
        super().begin_run()
        torch.accelerator.reset_peak_memory_stats()

    def end_run(self):
        import torch
        result=super().end_run()
        torch.accelerator.synchronize()
        result['memory']={
            'allocated':torch.accelerator.memory_allocated(),
            'reserved':torch.accelerator.memory_reserved(),
            'peak_allocated':torch.accelerator.max_memory_allocated(),
        }
        return result

    def diagnostic(self,action):
        from vllm.models.deepseek_v41.nvidia.flash_mla_mega_attn import DeepseekV4MegaAttnAttention as Mega
        if action=='reset':
            self.startup_projections=dict(self.projections)
            self.startup_padding=dict(self.padding)
            self.padding={'capture':0,'eager':0}
            self.projections={'capture':0,'eager':0}
            self.replays.clear()
        if action=='timing':
            Mega._wo_a_einsum=self.original_projection
            import vllm.models.deepseek_v41.nvidia.flash_mla_mega_attn as mega_module
            mega_module.pad_fused_q_heads=self.original_padding
            from vllm.v1.worker.gpu.cudagraph_utils import CudaGraphManager
            for name,original in self.graph_originals.items():setattr(CudaGraphManager,name,original)
        layers=[m for m in self.model_runner.get_model().modules() if isinstance(m,Mega)]
        return {'rank':self.rank,'padding':dict(self.padding),'startup_padding':getattr(self,'startup_padding',{}),'startup_projections':getattr(self,'startup_projections',{}),'graph_replays':dict(self.replays),'projections':dict(self.projections),'mega_layers':len(layers),
                'ready':all(m._fused_layouts_ready for m in layers),
                'local_heads':sorted({m.n_local_heads for m in layers}),
                'kv_dtype':sorted({m.kv_cache_dtype for m in layers}),
                'graph_mode':str(self.vllm_config.compilation_config.cudagraph_mode)}

def main(args):
    backend='FLASHMLA_MEGA_ATTN_DSV41' if args.backend=='mega' else 'FLASHMLA_SPARSE_DSV41'
    import subprocess,vllm
    source=Path(vllm.__file__).resolve().parent.parent
    diff=subprocess.check_output(['git','diff','HEAD'],cwd=source)
    report={'backend':args.backend,'kv_cache_dtype':args.kv_dtype,'cases':[],
            'source':str(source),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),
            'diff_sha256':hashlib.sha256(diff).hexdigest()}
    Path(args.output).with_suffix('.source.patch').write_bytes(diff)
    path=Path(args.output)
    def save():path.write_text(json.dumps(report,indent=2)+'\n')
    save()
    llm=LLM(model='/data/models/DeepSeek-V4.1-Flash',tokenizer_mode='deepseek_v41',
        tensor_parallel_size=4,language_model_only=True,enforce_eager=False,
        enable_prefix_caching=False,max_model_len=33792,max_num_seqs=4,max_num_batched_tokens=8192,
        kv_cache_memory_bytes=4*2**30,seed=0,disable_log_stats=False,
        kv_cache_dtype=args.kv_dtype,
        attention_config={'backend':backend,'indexer_kv_dtype':'fp8'},
        compilation_config={'cudagraph_capture_sizes':[1,2,4,32,64]},
        kernel_config={'enable_jit_warmup':False,'enable_cutedsl_warmup':False,'enable_flashinfer_autotune':False},
        engram_config={'cpu_offload':True},worker_cls='mega_bench.MegaWorker')
    llm.collective_rpc('diagnostic',args=('reset',))
    check=llm.chat([{'role':'user','content':'What is 17 times 19? Return only the integer.'}],SamplingParams(temperature=0,max_tokens=16),chat_template_kwargs={'thinking':False},use_tqdm=False)[0]
    report['arithmetic']={'text':check.outputs[0].text,'tokens':check.outputs[0].token_ids}
    report['diagnostic']=llm.collective_rpc('diagnostic',args=('read',));save()
    print('DIAGNOSTIC',json.dumps(report['diagnostic']),flush=True)
    assert check.outputs[0].text.strip()=='323',check.outputs[0].text
    llm.collective_rpc('diagnostic',args=('timing',))
    short={'prompt_token_ids':list(check.prompt_token_ids)}
    assert len(short['prompt_token_ids'])==17
    mixed=[short,perf.make_prompts(llm,16384,1)[0]]
    report['mixed']=perf.run_batch(llm,mixed,32);save()
    for length in args.contexts:
        prompts=[short] if length==17 else perf.make_prompts(llm,length,1)
        item={'length':length,'prompt_sha256':hashlib.sha256(json.dumps(prompts).encode()).hexdigest(),
              'warmups':[],'runs':[]};report['cases'].append(item)
        for i in range(args.repeats+2):
            run=perf.run_batch(llm,prompts,64)
            item['warmups' if i<2 else 'runs'].append(run);save()
            print('RESULT',length,i,{k:run[k] for k in ['mean_tpot_ms','mean_ttft_ms','scheduler_signature']},flush=True)
    if args.gsm:
        import re
        data=json.loads((ROOT/'artifacts/dcp/gsm8k-subset.json').read_text())
        demos='\n\n'.join('Question: '+x['question']+'\nAnswer: '+x['answer'] for x in data['splits']['train'])
        chats=[[{'role':'user','content':'Solve the final problem using the examples. End your answer with #### followed by the final number.\n\n'+demos+'\n\nQuestion: '+x['question']+'\nAnswer:'}] for x in data['splits']['test']]
        outputs=llm.chat(chats,SamplingParams(temperature=0,max_tokens=1024),chat_template_kwargs={'thinking':False},use_tqdm=False)
        def extract(text):
            matches=re.findall(r'####\s*(-?[\d,]+(?:\.\d+)?)',text)
            return matches[-1].replace(',','') if matches else None
        report['gsm8k']=[{'id':i,'correct':extract(o.outputs[0].text)==extract(expected['answer']),'text':o.outputs[0].text,'tokens':o.outputs[0].token_ids,'finish_reason':o.outputs[0].finish_reason} for i,(o,expected) in enumerate(zip(outputs,data['splits']['test']))]
        report['gsm8k_correct']=sum(x['correct'] for x in report['gsm8k']);save()
        assert all(x['finish_reason']!='length' for x in report['gsm8k'])
        print('GSM8K',report['gsm8k_correct'],flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--backend',choices=['mega','split'],required=True);p.add_argument('--kv-dtype',default='fp8_ds_mla');p.add_argument('--contexts',type=int,nargs='+',default=[17,8192]);p.add_argument('--repeats',type=int,default=3);p.add_argument('--gsm',action='store_true');p.add_argument('--output',required=True);main(p.parse_args())
