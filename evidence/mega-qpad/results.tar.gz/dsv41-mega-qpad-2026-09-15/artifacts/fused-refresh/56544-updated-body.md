## Summary

This draft is now historical: #56344 closed after its base branch was deleted,
and #56935 is the replacement integration against main. #56935 already includes
the shared FP8 output buffers and downstream projection handoff described here.
The native caller-output capability landed in vllm-project/FlashMLA#23, which
credits @foraxe as co-author.

The implementation and measurements below apply to the original #56344 stack;
they are not new performance claims for #56935. Current work is validating
#56935 on MRV2 and a separate, small input-padding follow-up. There is no need
to port this seven-file output-side change a second time.

Fused V4.1 attention in #56344 allocates FP8 values/scales and runs wo_a inside the eager attention region. For piecewise prefill, that adds output allocation and projection dispatch to every replay. Allocate a graph-owned QuantizedActivation, fill it through FlashMLA's output-buffer API, and capture wo_a together with wo_b.

```text
ASIS (piecewise)
graph projections -> eager [attention + new FP8/SF + wo_a] -> graph wo_b
```

```text
PR (piecewise)
graph-owned FP8/SF -> eager [attention writes outputs] -> graph [wo_a + wo_b]
```

Full-graph decode already captures the projection. Preserve the original direct BF16 destination for pure split-KV fallback decode outside PIECEWISE mode, avoiding two added copies on that route. Floating-output backends retain Tensor output and explicit type guards.

## Dependencies and duplicate check

Historical stack on #56344, targeting `vllm-project/vllm:v41-megakernel`. Its original FlashMLA #22 dependency was superseded by merged #23. The replacement #56935 comes from `zyongye/vllm:v41-megakernel`, a different repository branch, and already implements this output-side capability. The original duplicate-work search predates #56935.

## Validation

- MRV2 on the current-main integration: short-input A/B/B/A with 32 exact token-matched outputs plus mixed requests, matching scheduler steps, PIECEWISE prefill and FULL decode. Eager prefill wo_a calls drop from 40 to zero per worker. Median TTFT 28.87 -> 25.13 ms (-13.0%), with both order comparisons favoring the candidate. TPOT 6.329 -> 6.324 ms; no decode speedup claimed. MRV2 long-context timing and split-KV fallback remain unqualified.
- FlashMLA caller-output API: 27 tests passed on GB200, including exact output/scale equality, independent optional destinations, sliced/padded buffers, invalid arguments, changing-input CUDA graph replay and FP4 secondary cache.
- MRV1 model correctness/performance on a current-main integration of #56344: TP4 GB200, 17/8192/32768 input tokens, 64 output tokens, no prefix cache, FULL_AND_PIECEWISE with capture sizes [1,2,4,32,64]. A/B/B/A order, two warmups and six measured requests per context/run. All 96 outputs and mixed prefill/decode outputs match token-for-token. Every worker executes 1/1/4 prefill steps and 63 nonempty decode steps.
- MRV1 short-prefill replay: baseline makes 40 eager wo_a calls; candidate makes zero. Decode uses a full graph in both cases. Diagnostic hooks are removed before timings.
- MRV1 pooled median 17-token TTFT: 41.85 -> 36.92 ms (-11.8%), with both order comparisons favoring the candidate. Long-input results were order-sensitive; no long-context speedup claimed. TPOT differences were at most 0.21%; no decode speedup claimed.
- MRV1 split-KV fallback copying caused a spot regression. The direct-output fallback correction preserves exact outputs and returns TPOT to about 6.13 ms versus 6.11 ms baseline. Final default-route short-context recheck remained correct at about 37.3 ms TTFT.
- Scoped pre-commit/mypy and commit hooks passed on both the current-main integration and this stacked branch. The fused consumer file is byte-identical between them. Model runs used the current-main integration, not the older parent branch; full-model ROCm and DBO are not qualified here.

[Report, raw results, tests, reproducible drivers and checksums](https://github.com/foraxe/FlashMLA/tree/e29669d88a0aabc1a6e36827c0572b5c1d9eccad/evidence/fused-outputs). Main integration base: 22258a2 + #56344 at 6ff1e20. Measured prototype: 74d2d52. Fallback-preserving integration: ce57852. Native output API: cbb0f5b.

Test commands, with the report's environment/model paths (native tests from the FlashMLA checkout; model runs from the vLLM integration):

```bash
.venv/bin/python -m pytest tests/test_output_buffer_api.py -q
VLLM_USE_V2_MODEL_RUNNER=1 .venv/bin/python fused_output_bench_mrv2.py --variant baseline --contexts 17 --trials 6 --output a.json
VLLM_USE_V2_MODEL_RUNNER=1 .venv/bin/python fused_output_bench_mrv2.py --variant candidate --contexts 17 --trials 6 --output b.json
```

AI assistance was used for implementation, testing and investigation. The submitting human reviewed and approved this follow-up.
