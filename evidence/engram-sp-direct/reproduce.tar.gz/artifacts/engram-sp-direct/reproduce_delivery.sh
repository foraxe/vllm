#!/bin/bash
set -euo pipefail
cd /workspace/vllm_dsv41
source artifacts/engram-sp-direct/env.sh
ulimit -c 0
case "${1:-}" in
  unit)
    cd vllm-engram-sp-direct
    .venv/bin/python -m pytest tests/kernels/test_engram.py tests/distributed/test_engram_dp_shard.py -q
    ;;
  batch1-control|batch1-direct|matrix-control|matrix-direct)
    mode=$1
    extra=()
    if [[ "$mode" == *-direct ]]; then extra=(--direct); fi
    script=delivery_bench
    if [[ "$mode" == matrix-* ]]; then script=matrix_bench; fi
    vllm-engram-sp-direct/.venv/bin/python "artifacts/engram-sp-direct/$script.py" "${extra[@]}" --output "${2:-/tmp/engram-$mode.json}"
    ;;
  *) echo 'Acquire GPU ownership first. Usage: reproduce_delivery.sh unit|batch1-control|batch1-direct|matrix-control|matrix-direct [output]' >&2;exit 2;;
esac
