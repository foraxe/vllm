#!/bin/bash
set -euo pipefail
cd /workspace/vllm_dsv41
source artifacts/engram-sp-direct/env.sh
ulimit -c 0
for mode in control direct; do
  if [ -n "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)" ]; then exit 1; fi
  extra=()
  if [ "$mode" = direct ]; then extra=(--direct); fi
  vllm-engram-sp-direct/.venv/bin/python artifacts/engram-sp-direct/eval_recheck.py "${extra[@]}" --output "artifacts/engram-sp-direct/eval-recheck-$mode.json" > "artifacts/engram-sp-direct/eval-recheck-$mode.log" 2>&1
  echo "COMPLETED eval-recheck-$mode"
done
