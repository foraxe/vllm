import hashlib,json,statistics
from pathlib import Path
root=Path(__file__).resolve().parent
out={'pairs':{}}
for prefix in ['delivery','matrix']:
    control=json.loads((root/f'{prefix}-control.json').read_text())
    direct=json.loads((root/f'{prefix}-direct.json').read_text())
    rows=[]
    assert control['smoke']==direct['smoke']
    for c,d in zip(control['cases'],direct['cases']):
        assert (c['length'],c['batch'])==(d['length'],d['batch'])
        assert c['prompt_sha256']==d['prompt_sha256']
        cs={x['scheduler_signature'] for x in c['runs']}
        ds={x['scheduler_signature'] for x in d['runs']}
        row={'length':c['length'],'batch':c['batch'],'prompt_sha256':c['prompt_sha256'],
             'matched_scheduler':cs==ds,'control_scheduler':sorted(cs),'direct_scheduler':sorted(ds)}
        for name,case in [('control',c),('direct',d)]:
            assert len(case['runs'])==3
            row[name]={k:statistics.fmean(x[k] for x in case['runs']) for k in ['output_tokens_per_s','mean_ttft_ms','mean_tpot_ms','wall_s']}
            row[name]['rate_samples']=[x['output_tokens_per_s'] for x in case['runs']]
        row['rate_change_percent']=100*(row['direct']['output_tokens_per_s']/row['control']['output_tokens_per_s']-1)
        rows.append(row)
    out['pairs'][prefix]=rows
    if prefix=='delivery':
        assert control['eval_prompt_sha256']==direct['eval_prompt_sha256']
        out['gsm8k']={'control':control['gsm8k_correct'],'direct':direct['gsm8k_correct'],'total':len(control['gsm8k']),
                     'answer_matches':sum(x['answer']==y['answer'] for x,y in zip(control['gsm8k'],direct['gsm8k'])),
                     'changed_correctness_ids':[x['id'] for x,y in zip(control['gsm8k'],direct['gsm8k']) if x['correct']!=y['correct']],
                     'dataset_sha256':control['eval_dataset_sha256'],'source_revision':control['eval_source_revision']}
    print(prefix,rows)
(root/'delivery-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print('GSM8K',out['gsm8k'])
