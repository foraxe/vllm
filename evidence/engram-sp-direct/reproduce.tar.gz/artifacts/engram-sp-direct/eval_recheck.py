"""Matched SP Engram model validation; keeps all non-Engram configuration equal."""
import argparse,dataclasses,hashlib,json,os,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,'/workspace/vllm_dsv41/artifacts/dcp/performance')
import benchmark as perf
from vllm import LLM,SamplingParams
ROOT=Path('/workspace/vllm_dsv41')

class EngramWorker(perf.PerfWorker):
    def load_model(self,**kwargs):
        import torch
        from vllm.models.deepseek_v41.nvidia import engram as e
        self.allocations=[]
        original=e.DPSharedEngramStorage._allocate
        def allocate(storage,num_bytes):
            start=time.perf_counter();result=original(storage,num_bytes)
            self.allocations.append({'bytes':num_bytes,'seconds':time.perf_counter()-start})
            return result
        e.DPSharedEngramStorage._allocate=allocate
        start=time.perf_counter()
        try:super().load_model(**kwargs)
        finally:e.DPSharedEngramStorage._allocate=original
        torch.accelerator.synchronize()
        self.load_seconds=time.perf_counter()-start

    def diagnostic(self):
        from vllm.models.deepseek_v41.nvidia.engram import Engram,SPSharedEngramEmbedding
        rows=[]
        for m in self.model_runner.get_model().modules():
            if isinstance(m,Engram):
                e=m.embed_tokens
                rows.append({'direct':isinstance(e,SPSharedEngramEmbedding),'sp':m.use_sequence_parallel,
                    'parameter_rows':e.weight.shape[0],'lookup_heads':e.part_n_hash_cols,
                    'staging_shape':list(m.staged_rows.shape),'staging_bytes':m.staged_rows.numel()*2,
                    'parameter_bytes':e.weight.numel()+e.weight_scale_inv.numel(),
                    'mapped_bytes':e._shared_memory.weight.numel()+e._shared_memory.weight_scale_inv.numel() if e._shared_memory else 0})
        numa=[x.strip() for x in Path('/proc/self/numa_maps').read_text().splitlines() if 'vllm_engram_' in x]
        return {'rank':self.rank,'pid':os.getpid(),'runner':type(self.model_runner).__module__,
            'load_seconds':self.load_seconds,'allocations':self.allocations,'engram':rows,'numa_maps':numa,
            'cpu_affinity':sorted(os.sched_getaffinity(0))}


def make_document_prompts(llm,lengths):
    from vllm.renderers.params import ChatParams
    repo=ROOT/'vllm-engram-sp-direct'
    docs=sorted((repo/'docs/design').glob('*.md'))
    documents=[p.read_text() for p in docs]
    tokenizer=llm.get_tokenizer()
    result=[]
    for i,length in enumerate(lengths):
        corpus='\n\n'.join(documents[(i*3+j)%len(documents)] for j in range(12))
        ids=tokenizer.encode(corpus,add_special_tokens=False)
        assert len(ids)>length+128
        content=tokenizer.decode(ids[:length+128])
        messages=[{'role':'user','content':f'Review packet {i}.\n'+content+'\nExplain the main engineering tradeoffs in these documents. Give a detailed answer with concrete examples.'}]
        _,rendered=llm.llm_engine.renderer.render_chat([messages],ChatParams(chat_template_kwargs={'thinking':False,'add_generation_prompt':True}))
        ids=rendered[0]['prompt_token_ids']
        ids=ids[:length-128]+ids[-128:]
        assert len(ids)==length
        result.append({'prompt_token_ids':ids})
    return result

def main(a):
    path=Path(a.output)
    report={'direct':a.direct,'source_head':subprocess.check_output(['git','-C',str(ROOT/'vllm-engram-sp-direct'),'rev-parse','HEAD'],text=True).strip(),'cases':[]}
    diff=subprocess.check_output(['git','-C',str(ROOT/'vllm-engram-sp-direct'),'diff','HEAD'],text=True)
    path.with_suffix('.source.patch').write_text(diff)
    report['source_diff_sha256']=hashlib.sha256(diff.encode()).hexdigest()
    def save():path.write_text(json.dumps(report,indent=2)+'\n')
    save()
    start=time.perf_counter()
    llm=LLM(model='/data/models/DeepSeek-V4.1-Flash',tokenizer_mode='deepseek_v41',
        tensor_parallel_size=4,enable_expert_parallel=True,language_model_only=True,
        enforce_eager=False,enable_prefix_caching=False,max_model_len=9216,
        max_num_seqs=64,max_num_batched_tokens=8192,kv_cache_memory_bytes=4*2**30,
        seed=0,disable_log_stats=False,
        attention_config={'indexer_kv_dtype':'fp8'},
        compilation_config={'cudagraph_capture_sizes':[1,2,4,8,16,32,64]},
        kernel_config={'moe_backend':'deep_gemm_mega_moe','enable_jit_warmup':False,
          'enable_cutedsl_warmup':False,'enable_flashinfer_autotune':False},
        engram_config={'cpu_offload':True,'sp_shared_memory':a.direct},
        worker_cls='eval_recheck.EngramWorker')
    report['engine_init_s']=time.perf_counter()-start
    report['diagnostic']=llm.collective_rpc('diagnostic');save()
    assert all(e['sp'] and e['direct']==a.direct for d in report['diagnostic'] for e in d['engram'])
    checks=[(f'What is {i} times {j}? Return only the integer.',str(i*j)) for i,j in [(17,19),(13,7),(23,11),(29,3),(12,12),(31,4),(9,27),(18,16)]]
    filler=''.join(f'Entry {i}: blue item {(i*37)%97}. ' for i in range(260))
    checks += [('Remember secret code '+c+'. '+filler+' What was the secret code? Return only the code.',c) for c in ['314159','271828']]
    outputs=llm.chat([[{'role':'user','content':q}] for q,_ in checks],SamplingParams(temperature=0,max_tokens=16,stop=['\n']),chat_template_kwargs={'thinking':False},use_tqdm=False)
    report['smoke']=[{'expected':v,'text':o.outputs[0].text,'tokens':o.outputs[0].token_ids} for o,(_,v) in zip(outputs,checks)];save()
    assert all(x['text'].strip()==x['expected'] for x in report['smoke']),report['smoke']
    dataset_path=ROOT/'artifacts/dcp/gsm8k-subset.json'
    data=json.loads(dataset_path.read_text())
    report['eval_dataset_sha256']=hashlib.sha256(dataset_path.read_bytes()).hexdigest()
    report['eval_source_revision']=data['source_revision']
    demos='\n\n'.join('Question: '+x['question']+'\nAnswer: '+x['answer'] for x in data['splits']['train'])
    chats=[[{'role':'user','content':'Solve the final problem using the examples. End your answer with #### followed by the final number.\n\n'+demos+'\n\nQuestion: '+x['question']+'\nAnswer:'}] for x in data['splits']['test']]
    report['eval_prompt_sha256']=hashlib.sha256(json.dumps(chats).encode()).hexdigest()
    for repeat in range(2):
        results=llm.chat(chats,SamplingParams(temperature=0,max_tokens=2048),chat_template_kwargs={'thinking':False},use_tqdm=False)
        import re
        def extract(text):
            matches=re.findall(r'####\s*(-?[\d,]+(?:\.\d+)?)',text)
            return matches[-1].replace(',','') if matches else None
        report['gsm8k']=[{'id':i,'expected':extract(expected['answer']),'answer':extract(result.outputs[0].text),
          'correct':extract(result.outputs[0].text)==extract(expected['answer']),
          'text':result.outputs[0].text,'tokens':result.outputs[0].token_ids,'finish_reason':result.outputs[0].finish_reason}
          for i,(result,expected) in enumerate(zip(results,data['splits']['test']))]
        report['gsm8k_correct']=sum(x['correct'] for x in report['gsm8k']);save()
        report['eval_truncated_ids']=[x['id'] for x in report['gsm8k'] if x['finish_reason']=='length'];save()
        print('GSM8K',report['gsm8k_correct'],len(report['gsm8k']),flush=True)
        report.setdefault('eval_repeats',[]).append({'repeat':repeat,'correct':report['gsm8k_correct'],'truncated':report['eval_truncated_ids'],'answers':report['gsm8k']});save()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--direct',action='store_true');p.add_argument('--output',required=True);main(p.parse_args())
